# CarLink 开发包说明（第二轮修复）

## 目录
- `CarLink_MultiProtocol_Starter/`：设备诊断 UI 与明确标记为未集成的协议接口；不是已完成的投屏接收端。
- `DiPlay_BuildKit/`：DiPlay 上游构建脚本。按当前上游要求检查 JDK 25、SDK 37、Build-Tools 36.0.0、NDK 28.2.13676358。
- `Build_MiAuto_ICCOA.ps1`：MiAuto 上游构建脚本。缺少合法可用的 ICCOA SDK dex 时，不能将产物视为有效投屏接收端。
- `Build_Upstream_Receivers.ps1`：依次调用两个独立上游构建脚本；不会把不同协议实现自动合并为一个 APK。
- `协议接入说明/协议真实性与可实现范围.md`：协议边界说明。

## 在 Windows 上使用
1. 解压 ZIP。
2. 安装 Git、JDK 和 Android SDK。DiPlay 当前上游构建环境要求见其官方 `docs/BUILD.md`。
3. 在 PowerShell 运行：
   - `.\DiPlay_BuildKituild_diplay_debug.ps1`
   - `.\Build_MiAuto_ICCOA.ps1`
4. 每个脚本会在对应输出目录保存 APK 与 SHA-256 文件。
5. 必须再安装到真实车机，连接对应手机并检查视频、音频、触控、断线重连和 `adb logcat`。单纯构建成功不等于协议可用。

## 已知未解决/阻塞项
- 本包不包含 DiPlay/MiAuto 上游源码（构建时从 GitHub 拉取）。
- 本包不包含第三方受限 SDK、HiCar SDK、密钥或运行时认证文件。
- 不能在当前执行环境生成并验证最终 APK：没有 Android SDK/Gradle，且无法解析 GitHub DNS。
- HiCar 与 Android Auto 接收端仍未集成。
- 目前没有真实车机实测结果。

不要把当前 Starter 安装包称为支持全部协议的最终产品。
