﻿$ErrorActionPreference = "Stop"

# Builds the upstream ICCOA receiver project separately.
# This does not merge ICCOA into the CarLink starter and does not bypass the
# upstream requirement for a legitimately available protocol SDK dex.
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Repo = Join-Path $Root "upstream\MiAuto"
$Out = Join-Path $Root "artifacts\MiAuto"
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Repo) | Out-Null
New-Item -ItemType Directory -Force -Path $Out | Out-Null

function Check-NativeExit([string]$Operation) {
    if ($LASTEXITCODE -ne 0) { throw "$Operation 失败，退出码：$LASTEXITCODE。" }
}
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw "未找到 Git。请安装 Git for Windows 后重试。"
}
if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
    throw "未找到 Java。请安装 JDK 17 或更高版本。"
}
$javaVersion = (& java -version 2>&1 | Out-String)
if ($javaVersion -notmatch 'version "(\d+)') { throw "无法识别 Java 版本：$javaVersion" }
$javaMajor = [int]$Matches[1]
if ($javaMajor -lt 17) { throw "当前 Java 版本为 $javaMajor；请安装 JDK 17 或更高版本。" }

$sdk = $env:ANDROID_HOME
if (-not $sdk) { $sdk = $env:ANDROID_SDK_ROOT }
if (-not $sdk) {
    Write-Warning "未设置 ANDROID_HOME / ANDROID_SDK_ROOT。请确认 Android SDK 36、NDK 29.0.14206865 和 CMake 3.22.1 已安装，并配置 local.properties。"
}

if (Test-Path $Repo) {
    if (-not (Test-Path (Join-Path $Repo ".git"))) {
        throw "目标目录已存在但不是 Git 仓库：$Repo。请手动重命名/移走该目录后重试，避免脚本误删文件。"
    }
    git -C $Repo pull --ff-only
    Check-NativeExit "git pull"
} else {
    git clone --depth 1 https://github.com/PiggyBackBayonet/MiAuto.git $Repo
    Check-NativeExit "git clone"
}

$Readme = Join-Path $Repo "README.zh-CN.md"
if (-not (Test-Path $Readme)) { $Readme = Join-Path $Repo "README.md" }
if (Test-Path $Readme) {
    Write-Host "`n上游关于 SDK 的声明：" -ForegroundColor Cyan
    Select-String -Path $Readme -Pattern "协议层不在|protocol layer is not|SDK dex|Without the SDK dex|构建" |
        ForEach-Object { Write-Host $_.Line }
}

if (-not (Test-Path (Join-Path $Repo "gradlew.bat"))) {
    throw "缺少 gradlew.bat，源码目录可能不完整：$Repo"
}
Push-Location $Repo
try {
    Write-Host "`n开始运行上游测试与构建..." -ForegroundColor Cyan
    & .\gradlew.bat --no-daemon :app:testGithubDebugUnitTest :app:assembleGithubDebug
    Check-NativeExit "MiAuto Gradle build"

    $ApkDir = Join-Path $Repo "app\build\outputs\apk\github"
    $Apks = @(Get-ChildItem -Path $ApkDir -Filter "*.apk" -Recurse -ErrorAction SilentlyContinue)
    if ($Apks.Count -eq 0) { throw "构建命令返回成功，但没有找到 APK：$ApkDir" }
    foreach ($Apk in $Apks) {
        $target = Join-Path $Out $Apk.Name
        Copy-Item $Apk.FullName $target -Force
        $hash = (Get-FileHash $target -Algorithm SHA256).Hash
        Set-Content -Path "$target.sha256" -Value "$hash  $($Apk.Name)" -Encoding ASCII
        Write-Host "已复制 APK：$target" -ForegroundColor Green
        Write-Host "SHA-256：$hash"
    }
    Write-Warning "上游 README 明确说明公开仓库缺少预编译 ICCOA SDK dex。除非你合法配置了所需 SDK，构建成功也不代表具备 CarWith / Car+ / JoviInCar 投屏能力。"
} finally {
    Pop-Location
}
Write-Host "`n构建脚本结束。输出目录：$Out"
