﻿$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "CarLink 多接收端构建流程" -ForegroundColor Cyan
Write-Host "注意：此脚本构建独立上游 APK，不会把不同协议魔法般合并成一个 APK。"
Write-Host "DiPlay: CarPlay 接收端（需要按上游说明提供适当的运行时认证资产才能验证独立连接）"
Write-Host "MiAuto: ICCOA 接收端（公开源码缺少协议 SDK dex 时，APK 不具备 ICCOA 投屏能力）"
Write-Host ""

$di = Join-Path $Root "DiPlay_BuildKit\build_diplay_debug.ps1"
$mi = Join-Path $Root "Build_MiAuto_ICCOA.ps1"
if (-not (Test-Path $di)) { throw "找不到脚本：$di" }
if (-not (Test-Path $mi)) { throw "找不到脚本：$mi" }

Write-Host "== 第 1/2 步：DiPlay ==" -ForegroundColor Cyan
& $di
if ($LASTEXITCODE -ne 0) { throw "DiPlay 构建失败。请先修复上一步报错。" }

Write-Host "== 第 2/2 步：MiAuto ==" -ForegroundColor Cyan
& $mi
if ($LASTEXITCODE -ne 0) { throw "MiAuto 构建失败。请先修复上一步报错。" }

Write-Host "流程完成。请分别检查输出 APK 的 SHA-256、签名、安装启动及真实车机连接结果。"
