# CarLink 厂商车联协议开发包

本包在 CarLink Android 骨架基础上增加了真实协议范围说明，并附带 `Build_MiAuto_ICCOA.ps1`，用于在 Windows 上拉取并尝试构建 MiAuto 上游 ICCOA CarLink 接收端。

## 怎么用
1. 解压本包。
2. 安装 Git for Windows、JDK 17，以及上游所需 Android SDK / NDK。
3. 在 PowerShell 中运行 `Build_MiAuto_ICCOA.ps1`。
4. 输出目录为 `artifacts/MiAuto/`。
5. 查看 `协议接入说明/协议真实性与可实现范围.md`。

## 重要限制
- 本次执行环境不能访问 GitHub 克隆源码，因此没有将 MiAuto 上游源码打包进此文件。
- 构建脚本需要在你的 Windows 电脑上联网运行。
- MiAuto 上游 README 明确指出，ICCOA 协议 SDK 不在公开仓库中；缺少该 SDK 时，即使 Gradle 生成 APK，也不具备真实 ICCOA 投屏能力。
- 本包没有构建出最终 APK，也没有在实车上验证。
- MiAuto 采用 AGPL-3.0，修改/分发时请遵守许可证。
- HiCar 需要华为官方接入流程；不能伪造 SDK 或宣称已经支持。


## 本轮 Bug 修复（2026-10-19）
Starter 已修复 Android 15+ 系统栏遮挡、网络类型识别不完整、设备服务强制转换风险、误导性的存储诊断字段；DiPlay 构建脚本改为检查 JDK 17+，MiAuto 脚本避免误操作同名非 Git 目录。详见 `CarLink_MultiProtocol_Starter/docs/BUG_AUDIT_2026-10-19.md`。

**验证边界：** 当前环境没有 Android SDK / Gradle Wrapper，未能执行真实编译和实机测试，所以这是一份完成静态修复的源码开发包，不是已经验证可安装的 APK。厂商专有协议仍需官方 SDK / 授权和实机验收。
