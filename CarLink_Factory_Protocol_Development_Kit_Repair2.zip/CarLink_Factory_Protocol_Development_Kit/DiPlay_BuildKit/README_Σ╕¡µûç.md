# CarLink × DiPlay 构建工具包（比亚迪秦 Max 2026 款）

## 先说结论
本工具包会在你的 Windows 电脑上克隆 DiPlay 官方源码，并尝试构建 `:mobile:assembleDebug`。这属于**源码调试 APK**，上游文档明确指出：默认源码 APK 不含独立 CarPlay 连接所需的 runtime authentication assets，因此它不保证能直接连接 iPhone。

如需马上测试 CarPlay，请优先查看官方发布页并下载作者发布的 APK：
https://github.com/shihabal3amri/DiPlay/releases/latest

DiPlay 官方 README 当前公开预览版本为 0.2.21；它面向兼容的比亚迪 Android 车机，支持有线与无线 CarPlay，但不保证秦 Max 2026 款具体固件一定兼容。请先确认车机 Android/DiLink 版本，并在停车状态下测试。

## Windows 使用方法
1. 安装 Git for Windows。
2. 安装 Android Studio，并在 SDK Manager 安装 Android SDK Platform 37、Build Tools 36.0.0、Platform-Tools、NDK 28.2.13676358。
3. 安装并选择 JDK 25。上游当前构建说明要求 JDK 25。
4. 解压本工具包。
5. 右键 `build_diplay_debug.ps1` → 使用 PowerShell 运行；若策略阻止，可在 PowerShell 中进入该目录运行：
   `powershell -ExecutionPolicy Bypass -File .\\build_diplay_debug.ps1`
6. 源码构建完成后，APK 路径为 `DiPlay\\mobile\\build\\outputs\\apk\\debug\\mobile-debug.apk`。

脚本不会下载、创建或伪造任何厂商认证密钥，也不会尝试绕过认证。它只构建官方公开源码中的 debug 变体。

## 协议状态
- CarPlay：DiPlay 上游接收端已有有线/无线实现；车机具体固件和 iOS 组合仍需实测。
- Android Auto：本工具包未实现。
- vivo JoviInCar：未实现/未验证。
- 小米 CarWith：未实现/未验证。
- 华为 HiCar：未实现/未验证。
- 鸿蒙无线镜像：未实现；普通 Android APK 不会自动获得 HiCar 或系统级投屏接收能力。

## 为什么暂时不把其他协议写成“已支持”
各车联协议可能需要不同角色、系统服务、SDK、认证或厂商许可。把协议名称显示在菜单里，不等于实现了连接。下一阶段应先确认秦 Max 2026 款的 Android/DiLink 版本，验证 DiPlay，再对每个 Android/华为方案独立评估。

## 许可证
DiPlay 上游基于 GPL-3.0，界面/网站部分还涉及 AGPL-3.0。若分发修改版本，应保留上游声明并遵守各自许可证。详见官方仓库：
https://github.com/shihabal3amri/DiPlay
