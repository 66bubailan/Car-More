﻿$ErrorActionPreference = "Stop"
$repo = Join-Path $PSScriptRoot "DiPlay"
$dest = Join-Path $PSScriptRoot "output"
$logDir = Join-Path $PSScriptRoot "logs"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null

function Stop-WithMessage([string]$Message) {
  throw $Message
}
function Check-NativeExit([string]$Operation) {
  if ($LASTEXITCODE -ne 0) {
    Stop-WithMessage "$Operation 失败，退出码：$LASTEXITCODE。请查看终端输出。"
  }
}

$git = Get-Command git -ErrorAction SilentlyContinue
if (-not $git) { Stop-WithMessage "未找到 Git。请安装 Git for Windows：https://git-scm.com/download/win" }
if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
  Stop-WithMessage "未找到 Java。DiPlay 当前上游构建文档要求 JDK 25。"
}

$javaVersion = (& java -version 2>&1 | Out-String)
if ($javaVersion -notmatch 'version "(\d+)') { Stop-WithMessage "无法识别 Java 版本：$javaVersion" }
$javaMajor = [int]$Matches[1]
if ($javaMajor -ne 25) {
  Stop-WithMessage "检测到 Java $javaMajor。当前 DiPlay 上游构建说明要求 JDK 25；请安装 JDK 25 并调整 JAVA_HOME/PATH 后重试。"
}

$sdk = $env:ANDROID_HOME
if (-not $sdk) { $sdk = $env:ANDROID_SDK_ROOT }

$localProps = Join-Path $repo "local.properties"
if (-not $sdk -and (Test-Path $localProps)) {
  $line = Get-Content $localProps | Where-Object { $_ -match '^\s*sdk\.dir\s*=' } | Select-Object -First 1
  if ($line -match '^\s*sdk\.dir\s*=\s*(.+)$') { $sdk = $Matches[1].Trim().Replace('\\', '\') }
}
if (-not $sdk) {
  Stop-WithMessage "未设置 ANDROID_HOME / ANDROID_SDK_ROOT，且未在已存在的源码目录 local.properties 找到 sdk.dir。请先设置 SDK 环境变量，或先克隆源码并配置 local.properties。"
}
if (-not (Test-Path (Join-Path $sdk "platforms\android-37"))) {
  Stop-WithMessage "未找到 Android SDK Platform 37：$sdk\platforms\android-37。请通过 Android Studio SDK Manager 安装。"
}
if (-not (Test-Path (Join-Path $sdk "build-tools\36.0.0"))) {
  Stop-WithMessage "未找到 Android Build-Tools 36.0.0：$sdk\build-tools\36.0.0。请通过 SDK Manager 安装。"
}
if (-not (Test-Path (Join-Path $sdk "ndk\28.2.13676358"))) {
  Stop-WithMessage "未找到 NDK 28.2.13676358：$sdk\ndk\28.2.13676358。请通过 SDK Manager 安装。"
}

Write-Host "== Java / Android SDK 预检通过 ==" -ForegroundColor Green
java -version

if (-not (Test-Path $repo)) {
  Write-Host "== 克隆 DiPlay 官方源码 ==" -ForegroundColor Cyan
  git clone --depth 1 https://github.com/shihabal3amri/DiPlay.git $repo
  Check-NativeExit "git clone"
} else {
  if (-not (Test-Path (Join-Path $repo ".git"))) {
    Stop-WithMessage "源码目录存在但不是 Git 仓库：$repo。为避免覆盖用户文件，脚本已停止。"
  }
  Write-Host "== 更新 DiPlay 官方源码 ==" -ForegroundColor Cyan
  git -C $repo pull --ff-only
  Check-NativeExit "git pull"
}
if (-not (Test-Path (Join-Path $repo "gradlew.bat"))) {
  Stop-WithMessage "缺少 gradlew.bat，源码目录可能不完整：$repo"
}

Push-Location $repo
try {
  Write-Host "== 构建 DiPlay mobile debug APK ==" -ForegroundColor Cyan
  & .\gradlew.bat --no-daemon :mobile:assembleDebug
  Check-NativeExit "Gradle :mobile:assembleDebug"

  $apk = Join-Path $repo "mobile\build\outputs\apk\debug\mobile-debug.apk"
  if (-not (Test-Path $apk)) { Stop-WithMessage "Gradle 命令返回成功但没有找到 APK：$apk" }

  New-Item -ItemType Directory -Force -Path $dest | Out-Null
  $target = Join-Path $dest "DiPlay-mobile-debug.apk"
  Copy-Item $apk $target -Force
  $hash = (Get-FileHash $target -Algorithm SHA256).Hash
  Set-Content -Path "$target.sha256" -Value "$hash  $(Split-Path -Leaf $target)" -Encoding ASCII

  Write-Host "构建成功：$target" -ForegroundColor Green
  Write-Host "SHA-256：$hash"
  Write-Warning "这是 DiPlay 独立 APK，不是 CarLink 聚合 APK。源码 debug 构建默认不含独立 CarPlay 连接所需的认证运行时资产；请按官方 docs/BUILD.md 配置并执行 standalone 构建后再实测。"
} finally {
  Pop-Location
}
