# CarLink MultiProtocol Starter

> 状态：设备诊断 Starter，不是已经完成的车联接收端。当前代码不会完成 CarPlay、ICCOA CarLink、HiCar 或 Android Auto 握手、视频解码、音频传输或触控回传。

## 当前工程能力
- 检测车机 Android 版本、CPU ABI、USB Host 声明、USB 设备数量和网络传输类型。
- 导出设备诊断文本。
- 明确显示协议尚未集成，避免把占位适配器标为已连接。

## 构建
- 需要 Android Studio、Android SDK Platform 35、JDK 17+ 以及可联网下载的 Gradle 插件/依赖。
- 本 Starter 目录没有 Gradle Wrapper；请在安装了 Gradle 的开发环境中运行 `gradle :app:assembleDebug`，或在 Android Studio 中打开项目后同步并构建。
- 如果 Gradle/Android SDK 不可用，不能据此声称编译通过。
- 设备最低版本当前为 Android 8.0（API 26）。

## 协议集成路线
- CarPlay：单独构建 DiPlay，按其官方构建文档处理运行时认证资产。
- vivo JoviInCar / Xiaomi CarWith / OPPO Car+：研究并接入 MiAuto/ICCOA 接收端；公开仓库缺失的 SDK 必须合法获取。
- HiCar：按华为官方接入流程获取 SDK/权限并进行设备认证。
- Android Auto：需要独立接收端协议实现；不能由普通 Android 手机屏幕镜像替代。

详见 `docs/PROTOCOL_MATRIX.md` 和 `docs/BUG_AUDIT_2026-10-19.md`。

# CarLink Multi-Protocol Android Starter

## This update adds
- Real Android head-unit capability probe: manufacturer/model, Android API/release, CPU ABI, USB host feature, connected USB device count, Wi-Fi and active network transport.
- Shareable diagnostic report using Android's system share sheet.
- Protocol adapter lifecycle contract for CarPlay, Android Auto, JoviInCar, Car+, CarWith and HiCar.
- Explicit "not integrated" states rather than false claims that projection is working.
- Android 15+ system-bar inset handling, safer device-service probing, and improved build-script checks.
- See `docs/BUG_AUDIT_2026-10-19.md` for fixed items and the remaining real-device test checklist.

## What is not implemented yet
This is still not a complete projection receiver. The adapter contract is an integration seam, not the protocol itself. No video/audio transport, phone-to-car touch forwarding, proprietary JoviInCar/Car+/CarWith/HiCar protocol, or real DiPlay merge is included. A generic Android screen-capture permission does not substitute for a certified or proprietary car projection protocol.

## Build
Open this directory in Android Studio with Android SDK Platform 35, AndroidX dependencies, and JDK 17+. Run `assembleDebug`. This package does not currently include the Gradle Wrapper. The current environment did not validate a final APK build.

## Next engineering steps
1. Integrate upstream DiPlay source as a distinct module, respecting GPL-3.0 and AGPL-3.0 notices.
2. Add build flavors for modern / legacy / aftermarket devices and test ABI/API combinations.
3. Integrate each Android phone ecosystem only through documented or authorized receiver interfaces.
4. Run physical-device tests and label compatibility per exact head-unit model and firmware.
