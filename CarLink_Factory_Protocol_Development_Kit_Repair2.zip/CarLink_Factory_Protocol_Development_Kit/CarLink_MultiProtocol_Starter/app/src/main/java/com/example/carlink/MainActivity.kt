package com.example.carlink

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.example.carlink.core.HeadUnitProbe

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 18, 30)
    private val panel = Color.rgb(25, 33, 50)
    private val accent = Color.rgb(82, 170, 255)
    private val white = Color.rgb(242, 246, 255)
    private val muted = Color.rgb(165, 178, 200)
    private lateinit var diagnosticView: TextView
    private var diagnosticText = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            clipToPadding = false
        }
        // Android 15+ enforces edge-to-edge for targetSdk 35. Keep content clear
        // of status/navigation bars instead of allowing the first/last controls
        // to be hidden behind system UI.
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        scroll.addView(root)
        root.addView(label("CARLINK · MULTI-PROTOCOL", 12, accent, true))
        root.addView(label("多协议车联中心", 28, white, true).also { it.setPadding(0, dp(5), 0, dp(4)) })
        root.addView(label("新款 Android 车机 · 老款车机 · 后装车机", 14, muted, false))
        root.addView(spacer(18))
        root.addView(section("设备检测"))
        root.addView(actionButton("检测当前车机", "probe"))
        root.addView(actionButton("导出诊断报告", "share"))
        diagnosticView = label("尚未检测。点击“检测当前车机”读取 Android 版本、CPU ABI、USB 设备数量和网络状态。", 13, muted, false)
        diagnosticView.setPadding(dp(14), dp(14), dp(14), dp(14))
        diagnosticView.setBackgroundColor(panel)
        root.addView(diagnosticView, marginParams(bottom = 18))

        root.addView(section("协议接入状态"))
        val items = listOf(
            Triple("Apple CarPlay", "目标：有线 / 无线；需整合 DiPlay 并实机验证", "待集成"),
            Triple("Android 手机互联", "Android Auto 与厂商专有车联不是同一协议", "待适配"),
            Triple("vivo JoviInCar", "需可用接收端接口、协议资料及设备验证", "未实现"),
            Triple("Car+ 车联", "需确认具体产品、车机端和协议版本", "待确认"),
            Triple("小米 CarWith", "独立适配；不能由通用 Android 投屏自动替代", "未实现"),
            Triple("华为 HiCar / 鸿蒙", "需匹配 HiCar 接收端与设备组合", "未实现")
        )
        items.forEach { (name, desc, status) ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(15), dp(13), dp(15), dp(13))
                setBackgroundColor(panel)
            }
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            line.addView(label(name, 16, white, true), LinearLayout.LayoutParams(0, -2, 1f))
            line.addView(label(status, 12, accent, true))
            card.addView(line)
            card.addView(label(desc, 13, muted, false).also { it.setPadding(0, dp(7), 0, 0) })
            root.addView(card, marginParams(bottom = 9))
        }
        root.addView(spacer(12))
        root.addView(section("开发说明"))
        root.addView(label(
            "本版本已经加入真实的设备能力探测与诊断文本，但尚未集成投屏协议栈。不能把设备检测结果当作协议已支持。请停车后进行测试；请勿在驾驶中操作。",
            13, muted, false
        ))
        setContentView(scroll)
    }

    private fun handle(action: String) {
        when (action) {
            "probe" -> {
                diagnosticText = try { HeadUnitProbe.inspect(this).toDiagnosticText() }
                    catch (e: Exception) { "设备检测失败：${e.javaClass.simpleName}: ${e.message}" }
                diagnosticView.text = diagnosticText
                Toast.makeText(this, "设备检测完成", Toast.LENGTH_SHORT).show()
            }
            "share" -> {
                if (diagnosticText.isBlank()) {
                    Toast.makeText(this, "请先执行设备检测", Toast.LENGTH_SHORT).show()
                    return
                }
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "CarLink 车机诊断报告")
                    putExtra(Intent.EXTRA_TEXT, diagnosticText)
                }
                startActivity(Intent.createChooser(send, "分享诊断报告"))
            }
        }
    }

    private fun section(s: String) = label(s, 18, white, true).also { it.setPadding(0, 0, 0, dp(10)) }
    private fun actionButton(text: String, action: String): Button = Button(this).apply {
        this.text = text
        setTextColor(white)
        setBackgroundColor(panel)
        isAllCaps = false
        setOnClickListener { handle(action) }
        layoutParams = marginParams(bottom = 10)
    }
    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun spacer(height: Int) = TextView(this).apply { layoutParams = ViewGroup.LayoutParams(1, dp(height)) }
    private fun marginParams(bottom: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(bottom) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
