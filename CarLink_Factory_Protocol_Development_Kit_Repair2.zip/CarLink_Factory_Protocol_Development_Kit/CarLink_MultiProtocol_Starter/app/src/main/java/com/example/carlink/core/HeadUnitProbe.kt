package com.example.carlink.core

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.usb.UsbManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import java.util.Locale

data class HeadUnitCapabilities(
    val manufacturer: String,
    val model: String,
    val androidRelease: String,
    val apiLevel: Int,
    val supportedAbis: List<String>,
    val usbHostFeature: Boolean,
    val usbDevicesConnected: Int,
    val wifiEnabled: Boolean,
    val networkTransport: String
) {
    fun toDiagnosticText(): String = buildString {
        appendLine("CarLink 设备诊断")
        appendLine("厂商：$manufacturer")
        appendLine("型号：$model")
        appendLine("Android：$androidRelease (API $apiLevel)")
        appendLine("CPU ABI：${supportedAbis.joinToString()}")
        appendLine("USB Host：${if (usbHostFeature) "支持声明" else "未声明支持"}")
        appendLine("当前 USB 设备数：$usbDevicesConnected")
        appendLine("Wi-Fi：${if (wifiEnabled) "已开启" else "未开启/不可读取"}")
        appendLine("网络传输：$networkTransport")
        appendLine()
        appendLine("注意：能力探测不等于投屏协议兼容性认证。")
    }
}

object HeadUnitProbe {
    @Suppress("DEPRECATION")
    fun inspect(context: Context): HeadUnitCapabilities {
        val pm = context.packageManager
        val usbManager = context.getSystemService(Context.USB_SERVICE) as? UsbManager
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val network = cm?.activeNetwork
        val caps = if (cm != null && network != null) cm.getNetworkCapabilities(network) else null
        val transports = buildList {
            if (caps == null) {
                add("无活动网络")
            } else {
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) add("Wi-Fi")
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) add("以太网")
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) add("蜂窝网络")
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) add("VPN")
                if (isEmpty()) add("其他/未知")
            }
        }
        val transport = transports.joinToString("、")
        val abis = if (Build.VERSION.SDK_INT >= 21) Build.SUPPORTED_ABIS.toList()
                   else listOf(Build.CPU_ABI, Build.CPU_ABI2).filter { it.isNotBlank() }
        return HeadUnitCapabilities(
            manufacturer = Build.MANUFACTURER.orEmpty().ifBlank { "未知" }.replaceFirstChar { it.titlecase(Locale.ROOT) },
            model = Build.MODEL.orEmpty().ifBlank { "未知" },
            androidRelease = Build.VERSION.RELEASE.orEmpty(),
            apiLevel = Build.VERSION.SDK_INT,
            supportedAbis = abis,
            usbHostFeature = pm.hasSystemFeature(PackageManager.FEATURE_USB_HOST),
            usbDevicesConnected = usbManager?.deviceList?.size ?: 0,
            wifiEnabled = try { wifiManager?.isWifiEnabled == true } catch (_: SecurityException) { false },
            networkTransport = transport
        )
    }
}
