package com.example.carlink.core

/**
 * Shared lifecycle contract only. A real adapter must implement its own protocol,
 * handshake, video/audio pipeline, input forwarding, authorization and recovery.
 * Do not report CONNECTED until the underlying protocol confirms a session.
 */
enum class ProjectionProtocol {
    APPLE_CARPLAY,
    ANDROID_AUTO,
    VIVO_JOVI_IN_CAR,
    CAR_PLUS,
    XIAOMI_CARWITH,
    HUAWEI_HICAR
}

enum class AdapterState { UNAVAILABLE, READY, CONNECTING, CONNECTED, ERROR }

data class AdapterStatus(
    val protocol: ProjectionProtocol,
    val state: AdapterState,
    val message: String
)

interface ProtocolAdapter {
    val protocol: ProjectionProtocol
    fun inspect(capabilities: HeadUnitCapabilities): AdapterStatus
    fun connect(): AdapterStatus
    fun disconnect(): AdapterStatus
}

/**
 * Honest placeholder used until a protocol implementation is integrated.
 * It intentionally never claims that projection has started.
 */
class NotIntegratedAdapter(
    override val protocol: ProjectionProtocol,
    private val reason: String
) : ProtocolAdapter {
    override fun inspect(capabilities: HeadUnitCapabilities) = AdapterStatus(
        protocol, AdapterState.UNAVAILABLE,
        "$reason；当前版本未集成该协议的真实接收端"
    )
    override fun connect() = AdapterStatus(
        protocol, AdapterState.ERROR,
        "无法连接：协议实现尚未集成"
    )
    override fun disconnect() = AdapterStatus(
        protocol, AdapterState.READY,
        "没有活动会话"
    )
}
