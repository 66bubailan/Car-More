plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.carlink"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.carlink"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-scaffold"
    }
}


dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
