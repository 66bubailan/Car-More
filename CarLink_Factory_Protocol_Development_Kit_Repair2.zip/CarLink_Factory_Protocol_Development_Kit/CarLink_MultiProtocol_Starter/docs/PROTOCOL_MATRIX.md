# 协议适配矩阵与设计约束

## 架构建议
每个接收协议独立实现为 `ProjectionAdapter`，不要把协议名当作能力开关。建议接口包含：
- `isAvailable(deviceInfo)`：仅判断设备/系统条件，不承诺能连接
- `startSession(config)` / `stopSession()`
- `onVideoFrame`、`onAudioPacket`、`onInputEvent`
- 生命周期、权限、断线恢复和日志导出
- 明确的协议版本、认证状态、设备白名单/实测矩阵

## 建议状态枚举
`NOT_IMPLEMENTED`、`NEEDS_VENDOR_ACCESS`、`EXPERIMENTAL`、`DEVICE_TESTED`。
只有在真实设备上完成连接、音频、视频、触控、通话和恢复测试后，才可以标记 `DEVICE_TESTED`。

## 不能默认假设的事情
- CarPlay 接收端代码不等于 Android Auto 接收端。
- Android 手机和 Android 车机不是同一角色：JoviInCar / CarWith 等方案可能要求车机端服务或手机端特定系统组件。
- “鸿蒙”涵盖不同系统版本和设备形态，不能仅凭 HarmonyOS 名称推断 HiCar 可用。
- USB 连接需要确认数据角色、USB host/device 模式、驱动及设备枚举；无线连接需要确认发现、配对、认证和 Wi-Fi Direct/局域网策略。
- 不应伪造厂商身份、私钥或认证凭据；应使用公开接口、获得授权的 SDK 或官方认证流程。
